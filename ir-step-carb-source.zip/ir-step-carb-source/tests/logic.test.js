const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const html = fs.readFileSync(path.join(__dirname, '..', 'single-file.html'), 'utf8');
const scriptMatch = html.match(/<script>([\s\S]*?)<\/script>/);
assert.ok(scriptMatch, 'inline script exists');
const ids = Array.from(html.matchAll(/\bid="([^"]+)"/g), (match) => match[1]);
assert.equal(new Set(ids).size, ids.length, 'all HTML ids are unique');
const referencedIds = Array.from(scriptMatch[1].matchAll(/get\('([^']+)'\)/g), (match) => match[1]);
referencedIds.forEach((id) => assert.ok(ids.includes(id), 'missing element: ' + id));
const markup = html.replace(/<style>[\s\S]*?<\/style>/, '').replace(/<script>[\s\S]*?<\/script>/, '');
const tagStack = [];
const voidTags = new Set(['meta', 'input', 'br', 'hr', 'img', 'link']);
for (const match of markup.matchAll(/<(\/?)([a-z][a-z0-9-]*)\b[^>]*>/gi)) {
  const closing = match[1] === '/';
  const tag = match[2].toLowerCase();
  if (voidTags.has(tag)) continue;
  if (closing) {
    assert.equal(tagStack.pop(), tag, 'unbalanced HTML tag: ' + tag);
  } else {
    tagStack.push(tag);
  }
}
assert.equal(tagStack.length, 0, 'all HTML tags are closed');

const testScript = scriptMatch[1]
  .replace('      initialize();', '')
  .replace('    })();', '      globalThis.testApi = { calculatePlan, evaluateComparison, normalizeRecord, loadRecords, saveDraft, ui, state };\n    })();');
const storage = new Map();
const context = {
  document: { getElementById: () => null },
  localStorage: {
    getItem: (key) => storage.get(key) || null,
    setItem: (key, value) => storage.set(key, value),
    removeItem: (key) => storage.delete(key)
  },
  console
};
vm.runInNewContext(testScript, context);
const { calculatePlan, evaluateComparison, normalizeRecord, loadRecords, saveDraft, ui } = context.testApi;

function form(overrides = {}) {
  return {
    weightKg: 70,
    bodyFatPct: 25,
    scores: { mood: 6, energy: 6, sleep: 6 },
    sleepDuration: '7to8',
    symptoms: [],
    ...overrides
  };
}

function record(date, overrides = {}) {
  const plan = calculatePlan(form(overrides));
  return {
    date,
    savedAt: '2026-11-20T00:00:00.000Z',
    weightKg: plan.form.weightKg,
    bodyFatPct: plan.form.bodyFatPct,
    leanKg: plan.leanKg,
    macros: plan.macros,
    scores: plan.form.scores,
    sleepDuration: plan.form.sleepDuration,
    symptoms: plan.form.symptoms
  };
}

test('calculates lean mass and all three nutrients', () => {
  const result = calculatePlan(form());
  assert.equal(result.leanKg, 52.5);
  assert.equal(result.macros.proteinG, 105);
  assert.equal(result.macros.fatG, 42);
  assert.equal(result.macros.carbG, 157.5);
});

test('prioritizes dizziness and pauses carb reduction for hair loss', () => {
  const result = calculatePlan(form({
    scores: { mood: 2, energy: 2, sleep: 2 },
    sleepDuration: 'lt6',
    symptoms: ['dizzy', 'hairLoss']
  }));
  assert.equal(result.advice[0].level, 'urgent');
  assert.match(result.advice[0].body, /暂停继续降碳/);
  assert.ok(result.advice.some((item) => /脱发增多/.test(item.title)));
  assert.ok(result.advice.some((item) => /健康脂肪/.test(item.body)));
});

test('normalizes a saved JSON archive and rejects invalid scores', () => {
  const saved = JSON.parse(JSON.stringify(record('2026-11-20')));
  const normalized = normalizeRecord(saved);
  assert.equal(normalized.date, '2026-11-20');
  assert.equal(normalized.macros.carbG, 157.5);
  saved.scores.sleep = 11;
  assert.equal(normalizeRecord(saved), null);
});

test('reads saved records and persists the current form draft', () => {
  storage.set('ir-step-carb.records.v1', JSON.stringify([
    record('2026-11-18'),
    record('2026-11-20')
  ]));
  assert.deepEqual(Array.from(loadRecords(), (item) => item.date), ['2026-11-20', '2026-11-18']);

  ui.weight = { value: '70' };
  ui.bodyFat = { value: '25' };
  ui.mood = { value: '6' };
  ui.energy = { value: '7' };
  ui.sleepScore = { value: '8' };
  ui.sleepDuration = { value: '7to8' };
  ui.form = { querySelectorAll: () => [] };
  saveDraft();
  const draft = JSON.parse(storage.get('ir-step-carb.draft.v1'));
  assert.equal(draft.weightKg, '70');
  assert.equal(draft.energy, 7);
  assert.equal(draft.sleepDuration, '7to8');
});

test('comparison responds to lean mass loss and new symptoms', () => {
  const base = record('2026-11-18');
  const reduced = record('2026-11-20', { weightKg: 68, bodyFatPct: 25 });
  const changes = {
    weight: reduced.weightKg - base.weightKg,
    lean: reduced.leanKg - base.leanKg,
    mood: 0,
    energy: 0,
    sleep: 0
  };
  assert.match(evaluateComparison(base, reduced, changes).title, /瘦体重也下降/);
  reduced.symptoms = ['dizzy'];
  assert.equal(evaluateComparison(base, reduced, changes).level, 'urgent');
});

test('favorable comparison remains cautious', () => {
  const base = record('2026-11-18');
  const current = record('2026-11-20', {
    weightKg: 69,
    bodyFatPct: 24,
    scores: { mood: 7, energy: 7, sleep: 7 }
  });
  const changes = {
    weight: current.weightKg - base.weightKg,
    lean: current.leanKg - base.leanKg,
    mood: 1,
    energy: 1,
    sleep: 1
  };
  const assessment = evaluateComparison(base, current, changes);
  assert.equal(assessment.level, 'good');
  assert.match(assessment.text, /不足以判断/);
});
